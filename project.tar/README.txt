Sound level meter project made by hu jinrong, Feb.2018.

This prject is following GNU free liscence. The end user is free to modify
the  source code,but the developer takes no respomsibility
for any modification
 

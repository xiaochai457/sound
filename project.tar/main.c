//this file contains the main function of our project

#include<stdio.h>
// so far this main function contains nothing for our project
//as 
int main(void){
	printf("this is main function\n");
	foo(); // call a user-defined function
	return 0;
}

//function definition of foo()
#include<stdio.h>

void foo(void){
	printf("this is foo\n");
}
